--Database advantages over Spreadsheets:
--__They have more storage and they are more secure due to encryption
--__Many users can write queries to gather information from the data at the same TIME
--__The database is not changed in its core but it is presented according to the query
--__SQL Structured Query Language serves this purpose, it is used to create, consult & update RDDBB
--TABLES
--__They are data structured into rows and columns, which are often referred to as records and fields
--__Naming: Tables should start with lowercase and should not have spaces (use _ instead)
--__A record is a row holding information of an individual observation.
--__A field is a column that holds a piece of information about all records.
--__Field naming: they should be lowercase and not have white spaces, they should be singular. 
--__Field Names should not repeat and should be different from table names.
--IDENTIFIERS
--__They are fields that uniquely identify each record
--DATA
--__The data type has to be chosen according to the type of data stored. We use these
--__because different types of data are stored differently and take up different amount of space
--__It delimits the kind of operations that we can do with the data, such as multiplication for numbers.
--__string: sequence of characters. SQL has different type of string some limit the number of characters up to 250
--__VARCHAR is flexible and can store large strings
--__INTEGER (INT): store whole numbers, they have two be between -2000000 and 2000000
--__FLOAT (NUMBER): store fractional numbers, they can have 38 digits total (including those before and after decimal point)
--__DATABASE STORAGE: Information of a table fills physical space in our hard disk, but servers are centralized computers that
--__realize services via requests on a network. Servers can also access websites or files. Any computer can be a server if it
--__is configured to give that service. Most of the time are big and powerful machines as they are best equiped to deal with large 
--__amount of requests
--QUERIES
--__Reserved words: SELECT to access fields and FROM to access TABLES.
--__It is advised to capitalize reserved words and use lowercase for table and field names. 
--__It is also advised to end each line with a semicolon to indicate that the query is complete.
--__Query results are called RESULT SET.
--__To select multple fields we write their names separated by commas. Or use * to select all fields.
--__Aliasing is used to rename fields for clarity or brevity 
SELECT name AS first_name
FROM books;
--__Selecting distinct values of a field (DISTINCT)
SELECT DISTINCT year_hired
FROM employees;
--__Selecting unique combinations of fields
SELECT DISTINCT dept_id, year_hired
FROM employees;
--__VIEW: Saving SQL results. A view is a result set from a query
--__When a view is accessed it automatically updates with the underlying data
CREATE VIEW view_name AS
SELECT id, name, year_hired
FROM employees;
--__There is no result set when creating a view. Once a view is created we can query it just as a normal table